public class MediaDemo {
    public static void main(String[] args) {
        Dataset ds = new Dataset();

        Player p1 = new Player();
        Player p2 = new Player();
        Viewer v1 = new Viewer();
        Viewer v2 = new Viewer();

        ds.register(p1);
        ds.register(p2);
        ds.register(v1);
        ds.register(v2);

        System.out.println("\n--- Test Case 1: Adding Items and Observing Updates ---");
        ds.add(new Image("image1", "1920x1080", "Nature photo"));
        ds.add(new Image("image2", "800x600", "Portrait photo"));
        ds.add(new Audio("audio1", "180", "Pop music"));
        ds.add(new Audio("audio2", "240", "Classical music"));
        ds.add(new Video("video1", "300", "Movie clip"));
        ds.add(new Text("text1", "News article"));
        ds.add(new Text("text2", "Short story"));

        System.out.println("\nPlayer 1 playlist:");
        p1.showList();
        System.out.println("\nPlayer 2 playlist:");
        p2.showList();
        System.out.println("\nViewer 1 viewlist:");
        v1.showList();
        System.out.println("\nViewer 2 viewlist:");
        v2.showList();

        System.out.println("\n--- Test Case 2: 'next' and 'previous' Functionality (Player) ---");
        System.out.println("\nPlayer 1 currently playing:");
        ((Media) p1.currently_playing()).info();

        p1.next("audio");
        System.out.println("\nPlayer 1 currently playing after 'next(audio)':");
        ((Media) p1.currently_playing()).info();

        p1.previous("video");
        System.out.println("\nPlayer 1 currently playing after 'previous(video)':");
        ((Media) p1.currently_playing()).info();

        System.out.println("\n--- Test Case 3: 'next' and 'previous' Functionality (Viewer) ---");
        System.out.println("\nViewer 1 currently viewing:");
        ((Media) v1.currently_viewing()).info();

        v1.next("text");
        System.out.println("\nViewer 1 currently viewing after 'next(text)':");
        ((Media) v1.currently_viewing()).info();

        v1.previous("image");
        System.out.println("\nViewer 1 currently viewing after 'previous(image)':");
        ((Media) v1.currently_viewing()).info();

        System.out.println("\n--- Test Case 4: Removing Items and Observer Updates ---");
        Media audioToRemove = (Media) p1.currently_playing();
        ds.remove(audioToRemove);
        System.out.println("\nRemoved '" + audioToRemove.getTitle() + "' from the dataset.");
        System.out.println("\nPlayer 1 playlist after removal:");
        p1.showList();
        System.out.println("\nPlayer 2 playlist after removal:");
        p2.showList();

        Media imageToRemove = (Media) v1.currently_viewing();
        ds.remove(imageToRemove);
        System.out.println("\nRemoved '" + imageToRemove.getTitle() + "' from the dataset.");
        System.out.println("\nViewer 1 viewlist after removal:");
        v1.showList();
        System.out.println("\nViewer 2 viewlist after removal:");
        v2.showList();

        System.out.println("\n--- Test Case 5: Removing a Viewer Observer ---");
        ds.unregister(v2);
        ds.add(new Image("image3", "1024x768", "Landscape"));
        System.out.println("\nAdded 'image3'. Viewer 1 viewlist (should have image3):");
        v1.showList();
        System.out.println("\nViewer 2 viewlist (should NOT have image3):");
        v2.showList();

        System.out.println("\n--- Test Case 6: Empty Playlist/Viewlist Handling ---");
        ds.remove((Media) p1.currently_playing());
        ds.remove((Media) p1.currently_playing());

        System.out.println("\nPlayer 1 playlist after removing all items:");
        p1.showList();

        try {
            Playable currentPlayable = p1.currently_playing();
            System.out.println("\nPlayer 1 currently playing:");
            if (currentPlayable != null) {
                ((Media) currentPlayable).info();
            }
        } catch (RuntimeException e) {
            System.out.println("\nException: " + e.getMessage());
        }

        ds.remove((Media) v1.currently_viewing());
        ds.remove((Media) v1.currently_viewing());
        ds.remove((Media) v1.currently_viewing());
        ds.remove((Media) v1.currently_viewing());


        System.out.println("\nViewer 1 viewlist after removing all items:");
        v1.showList();

        try {
            Visual currentVisual = v1.currently_viewing();
            System.out.println("\nViewer 1 currently viewing:");
            if (currentVisual != null) {
                ((Media) currentVisual).info();
            }
        } catch (RuntimeException e) {
            System.out.println("\nException: " + e.getMessage());
        }

        v1.next("image");

        System.out.println("\n--- Test Case 7: Adding Items to Empty Lists ---");
        ds.add(new Audio("audio3", "300", "Jazz"));
        ds.add(new Text("text3", "Poem"));
        System.out.println("\nPlayer 1 playlist (should have audio3): ");
        p1.showList();
        System.out.println("\nViewer 1 viewlist (should have text3): ");
        v1.showList();
    }
}

/**
 * Abstract base class for all media objects.
 * This class represents a generic media item with a title and an abstract method to display information.
 */
abstract class Media {
    private String title;

    /**
     * Constructor to initialize the media title.
     *
     * @param title The title of the media.
     */
    public Media(String title) {
        this.title = title;
    }

    /**
     * Get the title of the media.
     *
     * @return The title of the media.
     */
    public String getTitle() {
        return title;
    }

    /**
     * Abstract method to display information about the media.
     */
    public abstract void info();
}

/**
 * Interface to categorize visual media objects.
 */
interface Visual {}

/**
 * Interface to categorize non-visual media objects.
 */
interface NonVisual {}

/**
 * Interface to categorize playable media objects.
 */
interface Playable {
    /**
     * Method to simulate playing the media.
     */
    void play();
}

/**
 * Interface to categorize non-playable media objects.
 */
interface NonPlayable {}

/**
 * Class representing text media.
 */
class Text extends Media implements Visual, NonPlayable {
    private String otherInfo;

    /**
     * Constructor to initialize the text media.
     *
     * @param title The title of the text.
     * @param otherInfo Additional information about the text.
     */
    public Text(String title, String otherInfo) {
        super(title);
        this.otherInfo = otherInfo;
    }

    @Override
    public void info() {
        System.out.println("Text: " + getTitle() + ", Info: " + otherInfo);
    }
}

/**
 * Class representing audio media.
 */
class Audio extends Media implements NonVisual, Playable {
    private String duration;
    private String otherInfo;

    /**
     * Constructor to initialize the audio media.
     *
     * @param title The title of the audio.
     * @param duration The duration of the audio.
     * @param otherInfo Additional information about the audio.
     */
    public Audio(String title, String duration, String otherInfo) {
        super(title);
        this.duration = duration;
        this.otherInfo = otherInfo;
    }

    @Override
    public void play() {
        System.out.println("Playing audio: " + getTitle());
    }

    @Override
    public void info() {
        System.out.println("Audio: " + getTitle() + ", Duration: " + duration + ", Info: " + otherInfo);
    }
}

/**
 * Class representing video media.
 */
class Video extends Media implements Visual, Playable {
    private String duration;
    private String otherInfo;

    /**
     * Constructor to initialize the video media.
     *
     * @param title The title of the video.
     * @param duration The duration of the video.
     * @param otherInfo Additional information about the video.
     */
    public Video(String title, String duration, String otherInfo) {
        super(title);
        this.duration = duration;
        this.otherInfo = otherInfo;
    }

    @Override
    public void play() {
        System.out.println("Playing video: " + getTitle());
    }

    @Override
    public void info() {
        System.out.println("Video: " + getTitle() + ", Duration: " + duration + ", Info: " + otherInfo);
    }
}

/**
 * Class representing image media.
 */
class Image extends Media implements Visual, NonPlayable {
    private String dimension;
    private String otherInfo;

    /**
     * Constructor to initialize the image media.
     *
     * @param title The title of the image.
     * @param dimension The dimensions of the image.
     * @param otherInfo Additional information about the image.
     */
    public Image(String title, String dimension, String otherInfo) {
        super(title);
        this.dimension = dimension;
        this.otherInfo = otherInfo;
    }

    @Override
    public void info() {
        System.out.println("Image: " + getTitle() + ", Dimension: " + dimension + ", Info: " + otherInfo);
    }
}
